/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.lab.based.practical.mock.http;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * ----------------
 * Please define a class named 'SimpleHttpServer' to encapsulate the HTTP server functionality.
 * ----------------
*/
public class SimpleHttpServer {
    private static final Logger LOGGER = Logger.getLogger(SimpleHttpServer.class.getName());

    /*
     * ----------------
     * Please define the main method, the entry point of the application.
     * This method sets up and starts the HTTP server.
     * ----------------
    */
    public static void main(String[] args) {
        LOGGER.info("Starting the HTTP server setup...");

        /*
         * ----------------
         * Please create an HttpServer instance called server that listens on port 8080. Set the backlog to 0
         * Use try-with-resources to ensure the server is closed properly.
         * ----------------
        */
        try {
            LOGGER.info("Creating HTTP server on port 8080...");
            HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
            LOGGER.info("HTTP server created successfully.");

            /*
             * ----------------
             * Create a context for "/myendpoint" and handle it with MyHandler.
             * ----------------
            */
            LOGGER.info("Creating context for '/myendpoint'...");
            server.createContext("/myendpoint", new MyHandler());
            LOGGER.info("Context created successfully.");

            /*
             * ----------------
             * Set the server's executor to null (no thread pool).
             * ----------------
            */
            LOGGER.info("Setting server executor to null...");
            server.setExecutor(null);
            LOGGER.info("Executor set successfully.");

            /*
             * ----------------
             * Start the server.
             * print "Server started on port 8080"
             * ----------------
            */
            LOGGER.info("Starting the HTTP server...");
            server.start();
            System.out.println("Server started on port 8080");
            LOGGER.info("Server started successfully on port 8080.");
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error starting server", e);
        }
    }

    /*
     * ----------------
     * Define a static inner class 'MyHandler' to handle HTTP requests to '/myendpoint'. 
     * This class implements HttpHandler 
     * ----------------
    */
    static class MyHandler implements HttpHandler {
        private static final Logger LOGGER = Logger.getLogger(MyHandler.class.getName());

        /*
         * -----------------------
         * Please override the handle method which accepts HttpExchange object called exchange which throws io exception
         * -----------------------
        */
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            LOGGER.info("Handling new HTTP request...");

            /*
             * ----------------
             * please get request method using exchange object and store it inside a string variable called string
             * please get the request URI and the related path using exchange object and store it in a string variable called path
             * ----------------
            */
            String method = exchange.getRequestMethod();
            String path = exchange.getRequestURI().getPath();
            LOGGER.info("Request Method: " + method + ", Path: " + path);

            /*
             * ----------------
             * if the endpoint equals path
                * invoke/call the sendResponse method and pass necessary arguments. 
                * then use return keyword
             * ----------------
            */
            if ("/myendpoint".equals(path)) {
                handleGetRequest(exchange);
                return;
            }

            /*
             * ---------------
             * check if the request method is "GET"
             * ---------------
            */
            if ("GET".equalsIgnoreCase(method)) {
                handleGetRequest(exchange);
            }
            /*
            * ------------------
            * otherwise check if the request method is "POST"
            * ------------------
            */
            else if ("POST".equalsIgnoreCase(method)) {
                /*
                 * ------------------
                 * define a string variable called response and store a message like "This is a POST request to /myendpoint"
                 * call sendResponse method and provide necessary arguments
                 * ------------------
                */
                String response = "This is a POST request to /myendpoint";
                sendResponse(exchange, response, 200);
            }
            /*
            * ----------------------
            * other wise Handle unsupported methods by calling sendResponse method and pass necessary arguments 
            * ----------------------
            */
            else {
                sendResponse(exchange, "Method Not Allowed", 405);
            }
        }

        /*
         * -------------------------
         * Please define a private void method called handleGetRequest which accepts an object of the HttpExchange called exchange, 
           throwing io exception
         * -------------------------
        */
        private void handleGetRequest(HttpExchange exchange) throws IOException {
            LOGGER.info("Handling GET request...");

            /*
             * -------------
             * Please define a string variable called response and include this message: "This is a GET request to /myendpoint"
             * -------------
            */
            String response = "This is a GET request to /myendpoint";
            LOGGER.info("Response: " + response);

            /*
             * -------------------
             * Please invoke sendResponse method and pass necessary arguments
             * -------------------
            */
            sendResponse(exchange, response, 200);
        }

        /*
         * -------------------------
         * Please define a private void method called sendResponse and pass these arguments: 
           HttpExchange object: exchange, a string variable response, an integer variable statusCode
         * -------------------------
        */
        private void sendResponse(HttpExchange exchange, String response, int statusCode) throws IOException {
            LOGGER.info("Sending response: " + response);

            /*
             * -------------
             * Please get response headers using exchange object and Set the "Content-Type" header to "text/plain".
             * -------------
            */
            exchange.getResponseHeaders().set("Content-Type", "text/plain");

            /*
             * ------------------
             * Please send response headers using exchange object and pass response code, 
               and convert the response to bytes and get the length of that
             * ------------------
            */
            exchange.sendResponseHeaders(statusCode, response.getBytes().length);

            /*
             * --------------------
             * Please define a try block and inside it create an object of the OutputStream called os 
               and get the response body using exchange object
             * Send the response using os object and pass response as its argument by converting it to bytes.
             * --------------------
            */
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(response.getBytes());
            }
            LOGGER.info("Response sent successfully.");
        }
    }
}